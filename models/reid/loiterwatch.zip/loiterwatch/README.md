# loiterwatch

A temporal rules engine for suspicious-loitering detection. It does **not** do
computer vision — it consumes track events from whatever detector you already
have (YOLO+ByteTrack, Frigate, an NVR, a commercial VMS) and decides when
behaviour over time becomes an alert.

That split is deliberate. Detection is a solved, swappable commodity; the part
that determines whether your operators trust the system is the temporal logic,
and that part should be declarative, testable, and replayable.

```
detector ──► tracker ──► zone events ──► [ loiterwatch ] ──► alerts
                          (JSONL/stream)     rules + state
```

## Quick start

```bash
pip install -e .
python -m loiterwatch replay examples/atm_events.jsonl -c examples/atm.yaml -v
```

Output on the bundled ATM scenario:

```
10:43:16  [!] WARNING  atm_no_card    UNEXPLAINED PRESENCE: track track-B at 'atm_lobby' for 45s
                                      with no card_inserted/transaction_complete
10:45:31  [!] WARNING  atm_dwell      LOITERING: track track-B present in 'atm_lobby' for 3m00s
               dwell=3m00s | since=10:42:31
10:51:45  [!] WARNING  atm_casing     REPEAT ENTRY: track track-C entered 'atm_lobby' 3x in 280s
10:52:31 [!!] CRITICAL atm_dwell      LOITERING: track track-B present in 'atm_lobby' for 10m00s
```

`track-A` — who walked up, inserted a card, and left — produces nothing. That is
the whole point: presence alone is not suspicious.

Other commands: `loiterwatch validate -c rules.yaml`, `loiterwatch types`.
Add `--speed 1` to replay in real time, `--json` for machine-readable alerts.

## Whole camera view as the restricted area

If there is no meaningful sub-zone to draw — anyone visible to the camera is
already somewhere they should not be — omit zones entirely. Events need no
`zone` field: each detection lands in a zone named after its `camera`, or in
`frame` if there is no camera either, and rules with no `zones:` list apply to
every camera.

```bash
python -m loiterwatch replay examples/restricted_events.jsonl -c examples/restricted_area.yaml
```

```
22:14:06 [!!] CRITICAL intrusion_night     INTRUSION: track track-A in restricted area 'cam_07' for 3s
22:14:33 [!!] CRITICAL intrusion_night     INTRUSION: track track-A in restricted area 'cam_07' for 30s
22:19:03 [!!] CRITICAL intrusion_night     INTRUSION: track track-A in restricted area 'cam_07' for 5m00s
22:30:43  [!] WARNING  perimeter_probing   REPEAT ENTRY: track track-C entered 'cam_07' 3x in 180s
```

A one-frame reflection and an engineer whose badge was granted both produce
nothing. Those two cases are what `confirm_s` and `cleared_by` exist for, and
they are the difference between a system operators trust and one they mute.

## Input format

One JSON object per line. The only required field is `ts`.

```json
{"ts": "2026-08-09T10:42:31Z", "kind": "observation", "zone": "atm_lobby", "track_id": "track-B", "confidence": 0.87}
{"ts": 1770000012.0,           "kind": "signal",      "zone": "atm_lobby", "signal": "card_inserted"}
{"ts": "2026-08-09T10:40:50Z", "kind": "exit",        "zone": "atm_lobby", "track_id": "track-A"}
{"ts": "2026-08-09T22:14:03Z", "camera": "cam_07", "track_id": "track-A", "confidence": 0.88}
```

The last line has no `zone`: the whole view of `cam_07` is the area of interest.

| kind | meaning |
|---|---|
| `observation` | track was seen inside the zone at `ts` — emit one per frame or per sample |
| `enter` / `exit` | explicit transitions, if your upstream already computes them |
| `signal` | non-vision business event: `card_inserted`, `transaction_complete`, `door_unlocked` |

`ts` accepts ISO-8601, epoch seconds, or epoch milliseconds. You only need
`observation` events — the engine derives entries and exits itself.

For live use, skip the CLI and drive the engine directly:

```python
from loiterwatch import Event, EventKind, load_config

engine = load_config("rules.yaml").engine(sinks=[my_notifier])
for track in tracker.stream():
    engine.ingest(Event(ts=track.ts, kind=EventKind.OBSERVATION,
                        zone=track.zone, track_id=track.id,
                        confidence=track.score))
```

## Rules

Rules are declared in YAML. Every rule accepts `id`, `type`, `zones`,
`severity`, `cooldown_s`, `min_confidence`, `active_hours`, `weekdays`,
`enabled`, and an optional `message` template.

### `dwell` — continuous presence past a threshold

```yaml
- id: atm_dwell
  type: dwell
  zones: [atm_lobby]
  min_observations: 3        # ignore one-frame phantoms
  thresholds:                # escalation; only the highest new level fires
    - {after_s: 180, severity: warning}
    - {after_s: 600, severity: critical}
```

Also: `threshold_s` for the single-level case, `repeat_every_s` to keep
re-alerting while the person is still there.

### `intrusion` — presence anywhere in view

```yaml
- id: intrusion_night
  type: intrusion
  confirm_s: 3               # reject single-frame detector noise
  min_observations: 3
  severity: critical
  cleared_by: [badge_granted]     # authorized entry cancels the alert
  active_hours: {start: "20:00", end: "06:00"}
  escalate:
    - {after_s: 30,  severity: critical}
    - {after_s: 300, severity: critical}
```

`confirm_s` is not a loitering threshold — it is only how long you wait before
believing the detector. Two or three seconds of consistent detections rejects
reflections, headlights, and blowing debris without meaningfully delaying a real
alert. Set `zones:` only when one camera needs a different policy.

### `repeat_entry` — casing

```yaml
- id: atm_casing
  type: repeat_entry
  zones: [atm_lobby]
  count: 3
  window_s: 900
  min_visit_s: 5             # a walk-past is not a visit
  min_gap_s: 20              # must actually leave in between
```

### `no_transaction` — presence with no business event to explain it

```yaml
- id: atm_no_card
  type: no_transaction
  zones: [atm_lobby]
  dwell_s: 45
  expects: [card_inserted, transaction_complete]
  scope: track               # or 'zone': any use of the machine clears everyone
```

In practice this is the strongest ATM signal available, because a card reader
gives you ground truth that no amount of video analysis can.

### Time-of-day gating

Loitering at 03:00 is not loitering at 13:00. Any rule can be scheduled:

```yaml
- id: atm_dwell_overnight
  type: dwell
  threshold_s: 90            # much lower bar at night
  severity: critical
  active_hours: {start: "23:00", end: "05:00"}
  weekdays: [fri, sat]       # optional
```

### Custom rules

```python
from loiterwatch import Rule, register

@register
class GroupApproachRule(Rule):
    type_name = "group_approach"
    def check(self, ctx):
        ...  # return a list of Alert
```

Any registered type is immediately usable from YAML.

## Design notes

**Exit grace is the load-bearing parameter.** Detectors drop frames and trackers
briefly lose people. Without `exit_grace_s`, a person standing perfectly still
at an ATM registers as twenty short visits and no dwell rule ever fires. The
engine holds a visit open for `exit_grace_s` after the last observation. Set it
above your worst observed tracking gap and below your shortest meaningful
absence — 3–8s is typical.

**The clock advances between events.** A threshold at 180s fires at exactly
T+180, not whenever the next frame happens to arrive. The engine steps its clock
forward in `tick_s` increments and evaluates at each step, which is also what
makes replay deterministic: the same log always yields the same alerts, so you
can tune thresholds against recorded incidents instead of guessing.

**Cooldowns are per-alert-identity**, keyed on rule + zone + track + visit, so a
single loiterer produces one alert per escalation level rather than one per
frame.

## Known limitations

- **Track ID switching is the dominant real-world failure mode.** If your
  tracker assigns a new ID after an occlusion, a 10-minute loiter looks like two
  5-minute visits. Fix this upstream (better re-ID, higher-FPS tracking) — no
  rule tuning compensates for it. A generous `exit_grace_s` helps only with
  short gaps.
- **Unattributed signals credit everyone in the zone.** A card reader cannot say
  *which* track inserted the card, so `scope: track` credits every person
  present at that moment. Use `scope: zone` if you would rather any machine use
  suppress alerts entirely.
- **Zone geometry is your problem.** The engine takes zone membership as given.
  Whether a foot-point falls inside the polygon, and how you handle perspective,
  is a detector-side concern.
- **Whole-frame mode inherits the camera's field of view.** With no polygon, the
  alert boundary is wherever the lens happens to point, so anything visible past
  the actual perimeter — a public footpath, a neighbouring property, a road —
  generates alerts you cannot tune away in the rules layer. Fix it by aiming or
  masking the camera, not by raising thresholds.
- **Timestamps are treated as UTC** when no offset is given, including in
  `active_hours`. Feed local-time offsets explicitly if your site cares.

## Tuning and deployment

Threshold choice is an operational decision, not a technical one. Every dwell
threshold trades missed incidents against operator alert fatigue, and an
alerting system that operators learn to ignore is worse than none. Replay a few
weeks of recorded events with `--json` and count what each candidate threshold
would have produced before you deploy it.

Worth stating plainly: "loitering" is a behavioural inference, not a fact. These
alerts should route a human to look at video, never trigger an automated
consequence on their own. Dwell time correlates with plenty of innocent
behaviour — waiting for someone, reading a phone, a person with limited
mobility, someone who needed three tries with the keypad. Keep alerts advisory,
log enough evidence for a reviewer to overrule the system quickly, and audit
false positives by location and time of day.

## Tests

```bash
pytest -q     # 57 tests
```

Coverage focuses on the temporal edge cases: exact threshold boundaries, grace
periods bridging dropouts, gaps that should reset the clock, out-of-order
events, cooldown suppression, replay determinism, single-frame noise rejection,
and authorization signals arriving before vs. after an alert.
