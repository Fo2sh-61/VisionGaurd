"""Command line interface: replay event logs through a rule config."""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone

from .alerts import Alert, Severity
from .config import load_config
from .engine import Engine
from .events import Event, EventKind, read_jsonl
from .rules.base import RULE_TYPES

_ICON = {Severity.INFO: "i", Severity.WARNING: "!", Severity.CRITICAL: "!!"}
_ANSI = {Severity.INFO: "\033[36m", Severity.WARNING: "\033[33m", Severity.CRITICAL: "\033[31m"}
_RESET = "\033[0m"


def _clock(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%H:%M:%S")


def _print_alert(alert: Alert, color: bool) -> None:
    tint, reset = (_ANSI[alert.severity], _RESET) if color else ("", "")
    print(
        f"{tint}{_clock(alert.ts)}  [{_ICON[alert.severity]}] "
        f"{alert.severity.value.upper():<8} {alert.rule_id:<22} {alert.message}{reset}"
    )
    ev = alert.evidence
    detail = []
    if "dwell_human" in ev:
        detail.append(f"dwell={ev['dwell_human']}")
    if "entries" in ev:
        detail.append(f"entries={ev['entries']}")
    if "entered_at" in ev:
        detail.append(f"since={_clock(ev['entered_at'])}")
    if "observed_signals" in ev:
        detail.append(f"signals={ev['observed_signals'] or 'none'}")
    if detail:
        print(f"{'':10}     {' | '.join(detail)}")


def cmd_replay(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    engine: Engine = config.engine()
    color = sys.stdout.isatty() and not args.no_color

    events = list(read_jsonl(args.events))
    if not events:
        print("no events in log", file=sys.stderr)
        return 1

    print(f"replaying {len(events)} events through {len(config.rules)} rules "
          f"({args.events})\n")

    wall_start = time.time()
    stream_start = events[0].ts
    seen_open: set[tuple[str, str]] = set()

    for event in events:
        if args.speed > 0:
            target = wall_start + (event.ts - stream_start) / args.speed
            delay = target - time.time()
            if delay > 0:
                time.sleep(delay)

        alerts = engine.ingest(event)

        if args.verbose:
            key = (event.zone, event.track_id or "-")
            if event.kind is EventKind.SIGNAL:
                print(f"{_clock(event.ts)}  ·  signal '{event.signal}' @ {event.zone}")
            elif key not in seen_open and event.kind is not EventKind.EXIT:
                seen_open.add(key)
                print(f"{_clock(event.ts)}  ·  {event.track_id} entered {event.zone}")
            elif event.kind is EventKind.EXIT:
                seen_open.discard(key)
                print(f"{_clock(event.ts)}  ·  {event.track_id} left {event.zone}")

        for alert in alerts:
            if args.json:
                print(json.dumps(alert.to_dict()))
            else:
                _print_alert(alert, color)

    for alert in engine.close():
        if args.json:
            print(json.dumps(alert.to_dict()))
        else:
            _print_alert(alert, color)

    if not args.json:
        by_sev: dict[str, int] = {}
        for alert in engine.alerts:
            by_sev[alert.severity.value] = by_sev.get(alert.severity.value, 0) + 1
        summary = ", ".join(f"{v} {k}" for k, v in sorted(by_sev.items())) or "none"
        print(f"\n{len(engine.alerts)} alert(s): {summary}")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    try:
        config = load_config(args.config)
    except Exception as exc:  # noqa: BLE001
        print(f"invalid config: {exc}", file=sys.stderr)
        return 1
    print(f"ok - {len(config.rules)} rule(s), {len(config.zones)} zone(s)")
    for rule in config.rules:
        scope = ", ".join(rule.zones) if rule.zones else "all zones"
        print(f"  - {rule.rule_id} ({rule.type_name}) -> {scope}")
    return 0


def cmd_types(_: argparse.Namespace) -> int:
    for name, cls in sorted(RULE_TYPES.items()):
        doc = (cls.__doc__ or "").strip().splitlines()[0] if cls.__doc__ else ""
        print(f"{name:<18} {doc}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="loiterwatch", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    replay = sub.add_parser("replay", help="run an event log through the rules")
    replay.add_argument("events", help="path to a JSONL event log")
    replay.add_argument("-c", "--config", required=True, help="path to rules YAML")
    replay.add_argument("--speed", type=float, default=0.0,
                        help="playback speed vs real time (0 = as fast as possible)")
    replay.add_argument("--json", action="store_true", help="emit alerts as JSON lines")
    replay.add_argument("-v", "--verbose", action="store_true", help="echo zone transitions")
    replay.add_argument("--no-color", action="store_true")
    replay.set_defaults(func=cmd_replay)

    validate = sub.add_parser("validate", help="check a rules YAML file")
    validate.add_argument("-c", "--config", required=True)
    validate.set_defaults(func=cmd_validate)

    types_cmd = sub.add_parser("types", help="list available rule types")
    types_cmd.set_defaults(func=cmd_types)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
